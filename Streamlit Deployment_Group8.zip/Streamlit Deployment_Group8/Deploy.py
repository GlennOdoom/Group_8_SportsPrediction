import streamlit as st
import joblib
import numpy as np

# Load machine learning model
fifa_model = joblib.load("FifaModelPred.pkl")

# Load the scaler used during model training
scaler = joblib.load("Scaling.pkl")

# Create the Streamlit app
st.title("FIFA Player Analysis App")

# Add Streamlit components and interactions for input features

st.header("Predict Player Overall Rating")

# Input features
dob = st.text_input("Enter Player Date of Birth (Year)", "1989-12-24")
dob_parts = dob.split('-')
if len(dob_parts) == 3:
    try:
        year = int(dob_parts[0])
        dob = float(year)  # Convert the input year to a float
    except ValueError:
        st.warning("Please enter a valid year for Date of Birth (e.g., 1989-12-24)")
        st.stop()
else:
    st.warning("Please enter Date of Birth in the format 'YYYY-MM-DD'")
    st.stop()

age = st.slider("Select Player Age", min_value=16, max_value=40, value=25)
value_eur = st.number_input("Enter Player Value in Euros", min_value=0, value=100000000)
release_clause_eur = st.number_input("Enter Player Release Clause in Euros", min_value=0, value=100000000)
sofifa_id = st.number_input("Enter Player SoFIFA ID", min_value=0, value=100000)
potential = st.slider("Select Player Potential", min_value=0, max_value=100, value=75)
movement_reactions = st.slider("Select Player Movement Reactions", min_value=0, max_value=100, value=70)
gk = st.slider("Select Player GK Rating", min_value=0, max_value=100, value=50)
rb = st.slider("Select Player RB Rating", min_value=0, max_value=100, value=60)
lb = st.slider("Select Player LB Rating", min_value=0, max_value=100, value=60)

# You can add more input features here

if st.button("Predict Player Rating"):
    # Prepare the input data for prediction
    input_data = np.array([[dob, age, value_eur, release_clause_eur, sofifa_id, potential, movement_reactions, gk, rb, lb]], dtype=object)
    
    # Scale the input data using the loaded scaler
    scaled_input_data = scaler.transform(input_data)
    
    # Make predictions using the FIFA model
    predicted_value = fifa_model.predict(scaled_input_data)
    st.write(f"Predicted Player overall rating : {predicted_value[0]}")

# Run the Streamlit app
if __name__ == "__main__":

    st.write("To view this app, use the following command in your terminal:")
    st.write("streamlit run your_script_name.py")
